package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editTextUsername, editTextPassword;
    Button buttonLogin, buttonRegister;
    String usernameHolder, passwordHolder;
    Boolean EmptyTextHolder;
    SQLiteDatabase db;
    UsersDB handler;
    String TempPassword = "NOT FOUND";
    public static final String UserName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        editTextUsername = findViewById(R.id.editUsernameText);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
        handler = new UsersDB(this);

        //Adding click listener to log in button.
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Calling EditText is empty or no method.
                CheckEditTextStatus();

                // Calling login method.
                LoginFunction();

                // Empty EditText After done inserting process.
                EmptyEditTextAfterDataInsert();
            }
        });

        // Adding click listener to register button.
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Opening new user registration activity using intent on button click.
                Intent intent = new Intent(MainActivity.this, Register.class);
                startActivity(intent);

            }
        });
    }

    public void LoginFunction() {
        if(EmptyTextHolder) {
            db = handler.getWritableDatabase();

            // Adding search username query to cursor
            Cursor cursor = db.query(UsersDB.TABLE_NAME, null, " "
                    + UsersDB.USERNAME_COLUMN + "=?", new String[]{usernameHolder}, null, null, null);

            while (cursor.moveToNext()) {

                if (cursor.isFirst()) {

                    // Storing Password associated with entered username
                    TempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersDB.PASSWORD_COLUMN));

                    // Closing cursor.
                    cursor.close();
                }
            }
            handler.close();

            // Calling method to check final result ..
            CheckFinalResult();
        }

        else {

            //If any of login EditText empty then this block will be executed.
            Toast.makeText(MainActivity.this,"Please Enter UserName or Password.",Toast.LENGTH_LONG).show();

        }

    }

    public void CheckEditTextStatus() {
        // Getting value from All EditText and storing into String Variables.
        usernameHolder = editTextUsername.getText().toString();
        passwordHolder = editTextPassword.getText().toString();

        // Checking EditText is empty or no using TextUtils.
        if( TextUtils.isEmpty(usernameHolder) || TextUtils.isEmpty(passwordHolder)){

            EmptyTextHolder = false ;

        }
        else {

            EmptyTextHolder = true ;
        }

    }

    // Empty edittext after done inserting process method.
    public void EmptyEditTextAfterDataInsert(){

        editTextUsername.getText().clear();

        editTextPassword.getText().clear();

    }

    // Checking entered password from SQLite database
    public void CheckFinalResult(){

        if(TempPassword.equalsIgnoreCase(passwordHolder)) {

            Toast.makeText(MainActivity.this,"Login Successful",Toast.LENGTH_LONG).show();

            // Going to Dashboard activity after login success message.
            Intent intent = new Intent(MainActivity.this, HomeDash.class);

            // Sending Email to Dashboard Activity using intent.
            intent.putExtra(UserName, usernameHolder);

            startActivity(intent);
        }
        else {

            Toast.makeText(MainActivity.this,"UserName or Password is Wrong, Please Try Again.",Toast.LENGTH_LONG).show();

        }
        TempPassword = "NOT_FOUND" ;

    }
}