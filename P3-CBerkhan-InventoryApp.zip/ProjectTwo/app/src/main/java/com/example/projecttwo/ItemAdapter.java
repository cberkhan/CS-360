package com.example.projecttwo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private List<Item> itemList;
    private OnDeleteItemClickListener onDeleteItemClickListener;
    private OnUpdateQuantityClickListener onUpdateQuantityClickListener;

    public ItemAdapter(List<Item> itemList, OnDeleteItemClickListener onDeleteItemClickListener, OnUpdateQuantityClickListener onUpdateQuantityClickListener) {
        this.itemList = itemList;
        this.onDeleteItemClickListener = onDeleteItemClickListener;
        this.onUpdateQuantityClickListener = onUpdateQuantityClickListener;
    }

    public void setItems(List<Item> itemList) {
        this.itemList = itemList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_row, parent, false);
        return new ViewHolder(view, onDeleteItemClickListener, onUpdateQuantityClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item item = itemList.get(position);
        holder.bind(item);
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView itemNameTextView;
        private TextView quantityTextView;
        private ImageButton deleteButton;
        private ImageButton increaseQuantityButton;
        private ImageButton decreaseQuantityButton;
        private OnDeleteItemClickListener onDeleteItemClickListener;
        private OnUpdateQuantityClickListener onUpdateQuantityClickListener;

        public ViewHolder(@NonNull View itemView, OnDeleteItemClickListener onDeleteItemClickListener, OnUpdateQuantityClickListener onUpdateQuantityClickListener) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            increaseQuantityButton = itemView.findViewById(R.id.increaseQuantityButton);
            decreaseQuantityButton = itemView.findViewById(R.id.decreaseQuantityButton);

            increaseQuantityButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && onUpdateQuantityClickListener != null) {
                        onUpdateQuantityClickListener.onUpdateQuantityClick(position, true);
                    }
                }
            });

            decreaseQuantityButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && onUpdateQuantityClickListener != null) {
                        onUpdateQuantityClickListener.onUpdateQuantityClick(position, false);
                    }
                }
            });

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        onDeleteItemClickListener.onDeleteItemClick(position);
                    }
                }
            });
        }

        public void bind(Item item) {
            itemNameTextView.setText(item.getItemName());
            quantityTextView.setText(item.getQuantity());
        }
    }

    public interface OnDeleteItemClickListener {
        void onDeleteItemClick(int position);
    }

    public interface OnUpdateQuantityClickListener {
        void onUpdateQuantityClick(int position, boolean increase);
    }
}
