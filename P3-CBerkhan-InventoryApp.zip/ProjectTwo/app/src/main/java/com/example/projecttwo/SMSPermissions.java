package com.example.projecttwo;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSPermissions extends AppCompatActivity {

    private Button accept, deny;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.permissions);

        accept = findViewById(R.id.buttonAccept);
        deny = findViewById(R.id.buttonDecline);

        //Click listener for the accept button
        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SMSPermissions.this, "Permission granted", Toast.LENGTH_SHORT).show();

                startActivity(new Intent(SMSPermissions.this, HomeDash.class));
                finish();
            }
        });
        //click listener for the decline button
        deny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SMSPermissions.this, "Permission denied", Toast.LENGTH_SHORT).show();

                startActivity(new Intent(SMSPermissions.this, HomeDash.class));
                finish();

            }
        });
    }

}


