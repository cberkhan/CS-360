package com.example.projecttwo;

public class Item {
    //Declare variables
    private String _quantity;
    private String _itemName;
    private int _ID;

    public Item() {
        super();
    }

    public Item (String qty, String itemName, int id) {
        this._quantity = qty;
        this._itemName = itemName;
        this._ID = id;
    }


    public void setItemID (int id) {
        this._ID = id;
    }

    public int getID() {
        return _ID;
    }

    public void setQuantity(String qty) {
        this._quantity = qty;
    }

    public String getQuantity() {
        return _quantity;
    }

    public void setItemName (String itemName) {
        this._itemName = itemName;
    }

    public String getItemName() {
        return _itemName;
    }
}
