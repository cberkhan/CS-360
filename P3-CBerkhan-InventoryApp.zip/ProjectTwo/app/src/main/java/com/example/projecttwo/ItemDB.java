package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class ItemDB extends SQLiteOpenHelper {

    //Create constant variables
    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "ItemDB";
    private static final String TABLE_NAME = "ItemTable";

    private static final String NAME_COLUMN = "Name";
    private static final String QUANTITY_COLUMN = "Quantity";
    private static final String ID_COLUMN = "ID";

    public ItemDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " (" + ID_COLUMN + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                NAME_COLUMN + " TEXT," + QUANTITY_COLUMN
                + " TEXT)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    //Add an item to the database
    public void addItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NAME_COLUMN, item.getItemName());
        values.put(QUANTITY_COLUMN, item.getQuantity());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    //Update an item from the database
    public int update(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NAME_COLUMN, item.getItemName());
        values.put(QUANTITY_COLUMN, item.getQuantity());

        return db.update(TABLE_NAME, values, ID_COLUMN + " = ?", new String[]
                { String.valueOf(item.getID()) });
    }

    //Delete an item from the database
    public void delete(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, ID_COLUMN + " = ?", new String[] { String.valueOf(item.getID()) });
        db.close();
    }

    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setItemID(Integer.parseInt(cursor.getString(0)));
                item.setItemName(cursor.getString(1));
                item.setQuantity(cursor.getString(2));

                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return itemList;
    }


}
