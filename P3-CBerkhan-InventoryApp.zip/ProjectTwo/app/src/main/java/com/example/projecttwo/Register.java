package com.example.projecttwo;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.Cursor;

import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {
    EditText editTextUsername, editTextPassword;
    Button buttonRegister, buttonCancel;
    String usernameHolder, passwordHolder;
    Boolean EmptyTextHolder;
    SQLiteDatabase db;
    UsersDB handler;
    String F_Result = "NOT FOUND";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        // Initialize UI elements
        editTextUsername = findViewById(R.id.editRegUsernameText);
        editTextPassword = findViewById(R.id.editRegTextPassword);
        buttonRegister = findViewById(R.id.buttonRegister);
        buttonCancel = findViewById(R.id.buttonCancel);
        handler = new UsersDB(this);

        // Adding click listener to register button.
        buttonRegister.setOnClickListener(view -> {

            // Checking EditText is empty or Not.
            CheckEditTextStatus();

            // Method to check Username already exists or not.
            CheckingUsernameAlreadyExistsOrNot();

            // Empty EditText After done inserting process.
            EmptyEditTextAfterDataInsert();

        });

        // Adding click listener to cancel button.
        buttonCancel.setOnClickListener(view -> {
            // Going back to LoginActivity after cancel Register
            startActivity(new Intent(Register.this, MainActivity.class));
            this.finish();
        });

    }


    // Insert data into SQLite database method.
    public void InsertNewUser(){

        // If editText is not empty then this block will executed.
        if(EmptyTextHolder == true)
        {
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();

            User user = new User(username, password);
            handler.addNewUser(user);

            // Printing toast message after done inserting.
            Toast.makeText(Register.this,"User Registered Successfully", Toast.LENGTH_LONG).show();

            startActivity(new Intent(Register.this, MainActivity.class));
            this.finish();

        }
        // This block will execute if any of the registration EditText is empty.
        else {

            // Printing toast message if any of EditText is empty.
            Toast.makeText(Register.this,"Please Fill All The Required Fields.", Toast.LENGTH_LONG).show();

        }

    }

    // Empty edittext after done inserting process method.
    public void EmptyEditTextAfterDataInsert(){

        editTextUsername.getText().clear();

        editTextPassword.getText().clear();

    }

    // Method to check EditText is empty or Not.
    public void CheckEditTextStatus(){

        // Getting value from All EditText and storing into String Variables.
        usernameHolder = editTextUsername.getText().toString();
        passwordHolder = editTextPassword.getText().toString();

        if(TextUtils.isEmpty(usernameHolder) || TextUtils.isEmpty(passwordHolder)){

            EmptyTextHolder = false ;

        }
        else {

            EmptyTextHolder = true ;
        }
    }

    // Checking Email is already exists or not.
    public void CheckingUsernameAlreadyExistsOrNot(){

        String username = editTextUsername.getText().toString();

        // Opening SQLite database write permission.
        db = handler.getWritableDatabase();

        // Adding search username query to cursor.
        Cursor cursor = db.query(UsersDB.TABLE_NAME, null, " " + UsersDB.USERNAME_COLUMN + "=?", new String[]{username}, null, null, null);

        while (cursor.moveToNext()) {

            if (cursor.isFirst()) {

                cursor.moveToFirst();

                // If Username already exists then Result variable value set as Username Found.
                F_Result = "Username Found";

                // Closing cursor.
                cursor.close();
            }
        }

        // Calling method to check final result and insert data into SQLite database.
        CheckFinalResult();

    }

    // Checking result
    public void CheckFinalResult(){

        // Checking whether username already exists or not.
        if(F_Result.equalsIgnoreCase("Username Found"))
        {

            // If email is exists then toast msg will display.
            Toast.makeText(Register.this,"Username Already Exists",Toast.LENGTH_LONG).show();

        }
        else {

            // If username already doesn't exist then user registration details will entered to SQLite database.
            InsertNewUser();

        }

        F_Result = "Not_Found" ;

    }

}

