package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeDash extends AppCompatActivity {

    private EditText editTextItemName, editTextQuantity;
    private Button buttonAddItem, buttonSMS;
    private RecyclerView recyclerViewItems;
    private ItemAdapter itemAdapter;
    private ItemDB itemDB;
    private List<Item> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        // Initialize UI elements
        editTextItemName = findViewById(R.id.ItemName);
        editTextQuantity = findViewById(R.id.Quantity);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonSMS = findViewById(R.id.buttonSMS);
        recyclerViewItems = findViewById(R.id.recyclerViewItems);

        // Initialize database handler
        itemDB = new ItemDB(this);

        itemList = new ArrayList<>();

        itemAdapter = new ItemAdapter(itemList, new ItemAdapter.OnDeleteItemClickListener() {
            @Override
            public void onDeleteItemClick(int position) {
                Item itemToDelete = itemList.get(position);
                itemDB.delete(itemToDelete);

                // Update the RecyclerView after deletion
                loadItems();
            }
        },
        new ItemAdapter.OnUpdateQuantityClickListener() {
            @Override
            public void onUpdateQuantityClick(int position, boolean increase) {
                // Handle increase or decrease quantity action
                updateQuantity(position, increase);

            }
        });

        // Initialize RecyclerView
        recyclerViewItems.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewItems.setAdapter(itemAdapter);

        // Set up click listener for the "Add Item" button
        buttonAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addItem();
            }
        });

        // Set up click listener for the "Settings" button
        buttonSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeDash.this, SMSPermissions.class));
                finish();
            }
        });

        // Load items from the database
        loadItems();
    }
    private void addItem() {
        // Get item details from the EditText
        String itemName = editTextItemName.getText().toString();
        String quantity = editTextQuantity.getText().toString();

        // Validate that the item name and quantity are not empty
        if (!TextUtils.isEmpty(itemName) && !TextUtils.isEmpty(quantity)) {
            // Create a new item object
            Item newItem = new Item();
            newItem.setItemName(itemName);
            newItem.setQuantity(quantity);

            // Add the item to the database
            itemDB.addItem(newItem);

            // Clear the EditText fields
            editTextItemName.setText("");
            editTextQuantity.setText("");

            // Reload the items from the database
            loadItems();
        } else {
            Toast.makeText(this, "Please enter both item name and quantity", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateQuantity(int position, boolean increase) {
        // Get the item at the specified position
        Item selectedItem = itemList.get(position);

        // Extract the current quantity
        String currentQuantity = selectedItem.getQuantity();
        if (TextUtils.isEmpty(currentQuantity)) {
            // Handle the case where quantity is empty
            return;
        }

        // Extract the current quantity
        int currentQty = Integer.parseInt(selectedItem.getQuantity());

        // Update the quantity based on the action (increase or decrease)
        int newQuantity = increase ? currentQty + 1 : Math.max(currentQty - 1, 0);

        // Set the new quantity to the item
        selectedItem.setQuantity(String.valueOf(newQuantity));

        // Update the quantity in the database
        itemDB.update(selectedItem);

        // Refresh the items in the RecyclerView
        loadItems();
    }

    private void loadItems() {
        // Load items from the database and update the RecyclerView
        itemList = itemDB.getAllItems();
        itemAdapter.setItems(itemList);
        itemAdapter.notifyDataSetChanged();
    }

}
